"""Contingency_CostModule Module Wrapper

TEAx module for Contingency_Cost calculation.

CAS29 contingency on direct costs:

  cost = contingency_rate * direct_subtotal

`contingency_rate` is the FOAK/NOAK rate (0.10 FOAK, 0.0 NOAK in the
source) -- a concept/maturity input (WI-011).

*Source**: /home/reid/1cfe/1costingfe/src/costingfe/layers/costs.py
*Ref**: costs.py:220 (cas29_contingency)
*Basis**: Fractional contingency on the direct-cost subtotal

Inputs:
    - direct_subtotal: direct_subtotal parameter
    - contingency_rate_in: contingency_rate_in parameter

Outputs:
    - cost: cost result

SysML Source: root-0/mfe_account_costs.sysml:311

SysML Source: root-0/mfe_account_costs.sysml:311

GAP: Code generator does NOT implement calc logic - only wrapper structure.
Handwritten implementation required in handwritten/mfe_account_costs/contingency_cost_impl.py
"""

from pydantic import BaseModel, Field, RootModel
from simkit.core.base import ModuleBase, ModuleResult

from aries_integrated.primitives import Float


class Contingency_CostInput(BaseModel):
    """Input model for Contingency_CostModule.

    Attributes:
        direct_subtotal: direct_subtotal input
        contingency_rate_in: contingency_rate_in input
    """
    direct_subtotal: float = Field(..., description="direct_subtotal input")
    contingency_rate_in: float = Field(..., description="contingency_rate_in input")


class Contingency_CostModule(ModuleBase[Contingency_CostInput, Float]):
    """TEAx module for Contingency_Cost calculation.

CAS29 contingency on direct costs:

  cost = contingency_rate * direct_subtotal

`contingency_rate` is the FOAK/NOAK rate (0.10 FOAK, 0.0 NOAK in the
source) -- a concept/maturity input (WI-011).

*Source**: /home/reid/1cfe/1costingfe/src/costingfe/layers/costs.py
*Ref**: costs.py:220 (cas29_contingency)
*Basis**: Fractional contingency on the direct-cost subtotal

Inputs:
    - direct_subtotal: direct_subtotal parameter
    - contingency_rate_in: contingency_rate_in parameter

Outputs:
    - cost: cost result

SysML Source: root-0/mfe_account_costs.sysml:311

    SysML Source: root-0/mfe_account_costs.sysml:311

    Calculation Specification:
        cost = contingency_rate_in * direct_subtotal
        
Documentation:
CAS29 contingency on direct costs:

  cost = contingency_rate * direct_subtotal

`contingency_rate` is the FOAK/NOAK rate (0.10 FOAK, 0.0 NOAK in the
source) -- a concept/maturity input (WI-011).

*Source**: /home/reid/1cfe/1costingfe/src/costingfe/layers/costs.py
*Ref**: costs.py:220 (cas29_contingency)
*Basis**: Fractional contingency on the direct-cost subtotal

    IMPLEMENTATION: See aries_integrated.handwritten.mfe_account_costs.contingency_cost_impl
    for manual implementation.

    NOTE: Single-output module - returns Float directly (no MultiOutput needed).
    """

    name: str = "Contingency_CostModule"
    version: str = "v0.1"

    def validate_and_fill_default(
        self, direct_subtotal: float, contingency_rate_in: float    ) -> Contingency_CostInput:
        """Validate inputs and fill defaults.

        Args:
            direct_subtotal: direct_subtotal input
            contingency_rate_in: contingency_rate_in input

        Returns:
            Validated input model
        """
        return Contingency_CostInput(direct_subtotal=direct_subtotal, contingency_rate_in=contingency_rate_in)

    def run(
        self, direct_subtotal: float, contingency_rate_in: float    ) -> ModuleResult[Float]:
        """Execute calculation.

        Args:
            direct_subtotal: direct_subtotal input
            contingency_rate_in: contingency_rate_in input

        Returns:
            Module result with Float (single-output mode)
        """
        # Validate inputs
        validated_inputs = self.validate_and_fill_default(direct_subtotal, contingency_rate_in)

        # Import handwritten implementation
        from aries_integrated.handwritten.mfe_account_costs.contingency_cost_impl import (
            run_contingency_cost,
        )

        # Execute implementation - returns single value
        cost = run_contingency_cost(validated_inputs)

        # Single output - return Float directly (RootModel[float])
        # TEAx assigns entire return value to the one channel declared in YAML
        return ModuleResult(data=Float(cost))
