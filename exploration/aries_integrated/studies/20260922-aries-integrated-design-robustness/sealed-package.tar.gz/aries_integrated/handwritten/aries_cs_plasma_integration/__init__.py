"""Handwritten implementations."""
