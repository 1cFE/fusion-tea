"""Levelized_Annual_CostModule Module Wrapper

TEAx module for Levelized_Annual_Cost calculation.

Levelized (growing-annuity) annual cost -- the shared CAS71/CAS80
wrapper:

  crf = i*(1+i)^n / ((1+i)^n - 1)
  a1  = annual_cost * (1+g)^Tc
  pv  = a1 * (1 - ((1+g)/(1+i))^n) / (i - g)
  levelized = crf * pv

A real annual stream escalating at g from the first operating year is
present-valued over n operating years at discount rate i, then
annuitized by CRF. `project_time` Tc is the construction period that
escalates the stream to its first operating year -- at NOAK that is
`construction_time` alone (1cfe adds licensing_time only when FOAK,
costs.py:41-44), so Tc = 8 at both the design and handshake points.

Used TWICE by the plant (MR-3, one def two usages): with
annual_cost = the unlevelized annual O&M -> CAS71, and with
annual_cost = the raw annual DT fuel cost -> CAS80.

Output-only Real declarations select typed native manual completion.

*Source**: /home/reid/1cfe/1costingfe/src/costingfe/layers/economics.py (pin 0254385)
*Ref**: economics.py:13-50 (levelized_annual_cost); economics.py:6-10 (CRF);
costs.py:41-44 (_total_project_time, NOAK omits licensing_time)
*Basis**: Growing-annuity present value annuitized by the capital recovery factor
Native manual completion evaluates the retained CRF*PV expression above
for Real N and T. A1 is construction-escalated annual_cost; its first
operating payment is discounted at year one. CRF(0,N)=1/N and
PV(i,i,N)=A1*N/(1+i). log1p/expm1 retain nearby represented rate differences.
Public outputs remain levelized and crf in the emitted wrapper order.

*Source**: models/library/analyses/mfe_account_costs.sysml
*Ref**: Levelized Annual Cost, CRF, construction-escalated A1, growing-annuity PV and levelized equations; work/active/WI-052_mfe-financial-rate-limits/design.md, Numerical method and justification
Preceding external citations are inherited and not reverified in WI-052.
*Basis**: equivalent rate-limit arithmetic; independent 100-digit factor and public-wrapper tests passed 2026-09-12
*Last Updated**: 2026-09-12 (native equation and numerical method verification)

Inputs:
    - interest_rate: interest_rate parameter
    - operational_years_in: operational_years_in parameter
    - inflation_rate_in: inflation_rate_in parameter
    - annual_cost: annual_cost parameter
    - project_time: project_time parameter

Outputs:
    - levelized: levelized result
    - crf: crf result

SysML Source: root-0/mfe_account_costs.sysml:747

SysML Source: root-0/mfe_account_costs.sysml:747

GAP: Code generator does NOT implement calc logic - only wrapper structure.
Handwritten implementation required in handwritten/mfe_account_costs/levelized_annual_cost_impl.py
"""

from pydantic import BaseModel, Field, RootModel
from simkit.core.base import ModuleBase, ModuleResult

from exchanger_architecture_thermal_tea.primitives import Float
from exchanger_architecture_thermal_tea.schemas.levelized_annual_cost_output import Levelized_Annual_CostOutput


class Levelized_Annual_CostInput(BaseModel):
    """Input model for Levelized_Annual_CostModule.

    Attributes:
        interest_rate: interest_rate input
        operational_years_in: operational_years_in input
        inflation_rate_in: inflation_rate_in input
        annual_cost: annual_cost input
        project_time: project_time input
    """
    interest_rate: float = Field(..., description="interest_rate input")
    operational_years_in: float = Field(..., description="operational_years_in input")
    inflation_rate_in: float = Field(..., description="inflation_rate_in input")
    annual_cost: float = Field(..., description="annual_cost input")
    project_time: float = Field(..., description="project_time input")


class Levelized_Annual_CostModule(ModuleBase[Levelized_Annual_CostInput, Levelized_Annual_CostOutput]):
    """TEAx module for Levelized_Annual_Cost calculation.

Levelized (growing-annuity) annual cost -- the shared CAS71/CAS80
wrapper:

  crf = i*(1+i)^n / ((1+i)^n - 1)
  a1  = annual_cost * (1+g)^Tc
  pv  = a1 * (1 - ((1+g)/(1+i))^n) / (i - g)
  levelized = crf * pv

A real annual stream escalating at g from the first operating year is
present-valued over n operating years at discount rate i, then
annuitized by CRF. `project_time` Tc is the construction period that
escalates the stream to its first operating year -- at NOAK that is
`construction_time` alone (1cfe adds licensing_time only when FOAK,
costs.py:41-44), so Tc = 8 at both the design and handshake points.

Used TWICE by the plant (MR-3, one def two usages): with
annual_cost = the unlevelized annual O&M -> CAS71, and with
annual_cost = the raw annual DT fuel cost -> CAS80.

Output-only Real declarations select typed native manual completion.

*Source**: /home/reid/1cfe/1costingfe/src/costingfe/layers/economics.py (pin 0254385)
*Ref**: economics.py:13-50 (levelized_annual_cost); economics.py:6-10 (CRF);
costs.py:41-44 (_total_project_time, NOAK omits licensing_time)
*Basis**: Growing-annuity present value annuitized by the capital recovery factor
Native manual completion evaluates the retained CRF*PV expression above
for Real N and T. A1 is construction-escalated annual_cost; its first
operating payment is discounted at year one. CRF(0,N)=1/N and
PV(i,i,N)=A1*N/(1+i). log1p/expm1 retain nearby represented rate differences.
Public outputs remain levelized and crf in the emitted wrapper order.

*Source**: models/library/analyses/mfe_account_costs.sysml
*Ref**: Levelized Annual Cost, CRF, construction-escalated A1, growing-annuity PV and levelized equations; work/active/WI-052_mfe-financial-rate-limits/design.md, Numerical method and justification
Preceding external citations are inherited and not reverified in WI-052.
*Basis**: equivalent rate-limit arithmetic; independent 100-digit factor and public-wrapper tests passed 2026-09-12
*Last Updated**: 2026-09-12 (native equation and numerical method verification)

Inputs:
    - interest_rate: interest_rate parameter
    - operational_years_in: operational_years_in parameter
    - inflation_rate_in: inflation_rate_in parameter
    - annual_cost: annual_cost parameter
    - project_time: project_time parameter

Outputs:
    - levelized: levelized result
    - crf: crf result

SysML Source: root-0/mfe_account_costs.sysml:747

    SysML Source: root-0/mfe_account_costs.sysml:747

    Calculation Specification:
        See documentation:
Levelized (growing-annuity) annual cost -- the shared CAS71/CAS80
wrapper:

  crf = i*(1+i)^n / ((1+i)^n - 1)
  a1  = annual_cost * (1+g)^Tc
  pv  = a1 * (1 - ((1+g)/(1+i))^n) / (i - g)
  levelized = crf * pv

A real annual stream escalating at g from the first operating year is
present-valued over n operating years at discount rate i, then
annuitized by CRF. `project_time` Tc is the construction period that
escalates the stream to its first operating year -- at NOAK that is
`construction_time` alone (1cfe adds licensing_time only when FOAK,
costs.py:41-44), so Tc = 8 at both the design and handshake points.

Used TWICE by the plant (MR-3, one def two usages): with
annual_cost = the unlevelized annual O&M -> CAS71, and with
annual_cost = the raw annual DT fuel cost -> CAS80.

Output-only Real declarations select typed native manual completion.

*Source**: /home/reid/1cfe/1costingfe/src/costingfe/layers/economics.py (pin 0254385)
*Ref**: economics.py:13-50 (levelized_annual_cost); economics.py:6-10 (CRF);
costs.py:41-44 (_total_project_time, NOAK omits licensing_time)
*Basis**: Growing-annuity present value annuitized by the capital recovery factor
Native manual completion evaluates the retained CRF*PV expression above
for Real N and T. A1 is construction-escalated annual_cost; its first
operating payment is discounted at year one. CRF(0,N)=1/N and
PV(i,i,N)=A1*N/(1+i). log1p/expm1 retain nearby represented rate differences.
Public outputs remain levelized and crf in the emitted wrapper order.

*Source**: models/library/analyses/mfe_account_costs.sysml
*Ref**: Levelized Annual Cost, CRF, construction-escalated A1, growing-annuity PV and levelized equations; work/active/WI-052_mfe-financial-rate-limits/design.md, Numerical method and justification
Preceding external citations are inherited and not reverified in WI-052.
*Basis**: equivalent rate-limit arithmetic; independent 100-digit factor and public-wrapper tests passed 2026-09-12
*Last Updated**: 2026-09-12 (native equation and numerical method verification)

    IMPLEMENTATION: See exchanger_architecture_thermal_tea.handwritten.mfe_account_costs.levelized_annual_cost_impl
    for manual implementation.

    NOTE: Uses MultiOutput pattern for type-safe multi-output support.
    TEAx automatically extracts levelized, crf fields to separate channels.
    """

    name: str = "Levelized_Annual_CostModule"
    version: str = "v0.1"

    def validate_and_fill_default(
        self, interest_rate: float, operational_years_in: float, inflation_rate_in: float, annual_cost: float, project_time: float    ) -> Levelized_Annual_CostInput:
        """Validate inputs and fill defaults.

        Args:
            interest_rate: interest_rate input
            operational_years_in: operational_years_in input
            inflation_rate_in: inflation_rate_in input
            annual_cost: annual_cost input
            project_time: project_time input

        Returns:
            Validated input model
        """
        return Levelized_Annual_CostInput(interest_rate=interest_rate, operational_years_in=operational_years_in, inflation_rate_in=inflation_rate_in, annual_cost=annual_cost, project_time=project_time)

    def run(
        self, interest_rate: float, operational_years_in: float, inflation_rate_in: float, annual_cost: float, project_time: float    ) -> ModuleResult[Levelized_Annual_CostOutput]:
        """Execute calculation.

        Args:
            interest_rate: interest_rate input
            operational_years_in: operational_years_in input
            inflation_rate_in: inflation_rate_in input
            annual_cost: annual_cost input
            project_time: project_time input

        Returns:
            Module result with Levelized_Annual_CostOutput (levelized, crf)
        """
        # Validate inputs
        validated_inputs = self.validate_and_fill_default(interest_rate, operational_years_in, inflation_rate_in, annual_cost, project_time)

        # Import handwritten implementation
        from exchanger_architecture_thermal_tea.handwritten.mfe_account_costs.levelized_annual_cost_impl import (
            run_levelized_annual_cost,
        )

        # Execute implementation - returns tuple of values
        levelized, crf = run_levelized_annual_cost(validated_inputs)


        # Return MultiOutput container (TEAx auto-extracts to channels)
        # MultiOutput fields use plain float (not RootModel[float])
        return ModuleResult(
            data=Levelized_Annual_CostOutput(
                levelized=levelized,
                crf=crf,
            )
        )
