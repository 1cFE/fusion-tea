"""Map retained native outputs to every frozen quantity without reference data."""
import argparse
import json
import math
from candidate_common import exclusive_document, mode_applicability
from pathlib import Path


def extract(manifest, contract, native):
    values = {p['qualified_name']: p['default_value'] for p in contract['parameters']}
    values.update(native.get('effective_inputs', {}))
    values.update(native.get('requested_overrides', {}))
    values.update(native.get('outputs', {}))
    # Native stores publish predicate verdicts separately from numeric outputs.
    for entry in contract['constraint_catalog']['concrete_entries']:
        verdict = native.get('verdicts', {}).get(entry['constraint_id'])
        if verdict in ('satisfied', 'violated'):
            values[entry['evaluation_channel']] = 1 if verdict == 'satisfied' else 0
    rows = []
    for q in manifest['quantities']:
        producers = q['producers']
        value, status = None, 'not_produced'
        if native.get('state') != 'completed':
            status = 'execution_not_completed'
        elif not producers:
            status = 'structural_evidence_required' if q['axis'] == 'structural' else 'not_produced'
        elif any(p not in values for p in producers):
            status = 'missing_producer'
        elif len(producers) == 1:
            value, status = values[producers[0]], 'mapped'
        elif q['calculation'] == 'sum of producers in cumulative radial order':
            value, status = sum(values[p] for p in producers), 'mapped'
        elif q['calculation'] == 'producer[0] - producer[1]' and len(producers) == 2:
            value, status = values[producers[0]]-values[producers[1]], 'mapped'
        else:
            raise ValueError(f"Unsupported frozen calculation for {q['id']}")
        if status == 'mapped' and (not isinstance(value, (float, int)) or not math.isfinite(value)):
            value, status = None, 'invalid_producer'
        raw_value = value
        availability = mode_applicability(q.get('availability_when', []), values)
        if status == 'mapped' and availability != 'active':
            value, status = None, 'inactive_prediction' if availability == 'inactive' else 'unknown_applicability'
        role = q['role']
        role_input = q.get('role_input', producers[0] if len(producers) == 1 else None)
        conditioning = native.get('conditioned_output_roles', {}).get(role_input)
        if role_input in native.get('conditioned_input_keys', []):
            conditioning = native.get('conditioned_input_roles', {}).get(role_input, 'supplied')
        if conditioning == 'supplied' or role_input in native.get('supplied_input_keys', []):
            role = 'supplied'
        elif role_input is not None and q['role'] in ('held', 'supplied'):
            role = 'held'
        rows.append({'id': q['id'], 'model_value': value, 'unit': q['unit'], 'status': status,
                     'role_at_this_point': role, 'producers': producers, 'reference_value': None,
                     'conditioning': conditioning, 'prediction_availability': availability,
                     'raw_model_value': raw_value,
                     # Export alone has no reference evidence and awards no match credit.
                     'independent_prediction_credit': False,
                     'applicability': q['applicability']})
    return {'run_kind': native.get('run_kind'), 'candidate_id': native.get('candidate_id'),
            'execution_status': native.get('state'), 'quantities': rows,
            'held_fallback': native.get('held_fallback'),
            'missing_independent_inputs': native.get('missing_independent_inputs', []),
            'conditioned_input_keys': native.get('conditioned_input_keys', []),
            'conditioned_input_roles': native.get('conditioned_input_roles', {}),
            'conditioned_supplied_quantities': native.get('conditioned_supplied_quantities', {}),
            'conditioned_output_roles': native.get('conditioned_output_roles', {}),
            'constraints': native.get('verdicts', {}), 'reference_values_loaded': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--native-result', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path.cwd())
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    def produce():
        manifest = json.loads(args.manifest.read_text())
        contract = json.loads((args.root / manifest['package_path'] / 'contracts/model_contract.json').read_text())
        return extract(manifest, contract, json.loads(args.native_result.read_text()))
    _, ok = exclusive_document(args.out, produce, inputs=[args.manifest,args.native_result])
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
