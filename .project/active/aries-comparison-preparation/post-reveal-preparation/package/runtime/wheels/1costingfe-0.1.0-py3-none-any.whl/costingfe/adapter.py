"""Fusion-tea adapter: typed interface between SysML pipeline and CostModel.

Provides:
- FusionTeaInput: flat dict from SysML-extracted parameters
- FusionTeaOutput: CAS-code-keyed cost breakdown + LCOE
- run_costing(): input -> output (the single function fusion-tea calls)
"""

from dataclasses import dataclass, field
from typing import Any

from costingfe.defaults import load_costing_constants
from costingfe.model import CostModel
from costingfe.types import (
    ConfinementConcept,
    Fuel,
    LaserDriverType,
    PowerCycle,
    PulsedConversion,
)
from costingfe.validation import CostingInput


@dataclass
class FusionTeaInput:
    """Parameters extracted from SysML model by fusion-tea."""

    concept: str  # e.g. "tokamak", "laser_ife", "mag_target"
    fuel: str  # e.g. "dt", "dd", "dhe3", "pb11"
    net_electric_mw: float
    availability: float
    lifetime_yr: float
    n_mod: float = 1.0
    # None = use the concept YAML's construction_time_yr (do not mask it).
    construction_time_yr: float | None = None
    interest_rate: float = 0.07
    inflation_rate: float = 0.02
    noak: bool = True
    power_cycle: str = "rankine"
    overrides: dict = field(default_factory=dict)
    cost_overrides: dict[str, float] = field(default_factory=dict)  # CAS account → M$
    pulsed_conversion: str = (
        ""  # "" means use concept default; "thermal" or "inductive_dec"
    )
    laser_driver_type: str = ""  # "" = concept default; "dpssl" | "krf" | "nd_glass"
    costing_overrides: dict[str, float] = field(
        default_factory=dict
    )  # CostingConstants field → value
    # When set, cost_overrides are absolute M$ valid at this reference power and
    # scaled to net_electric_mw. None means cost_overrides apply directly.
    override_reference_mw: float | None = None


@dataclass
class FusionTeaOutput:
    """Cost breakdown in CAS-code-keyed format for fusion-tea."""

    lcoe: float  # $/MWh
    overnight_cost: float  # M$ (CAS10-50, excludes IDC)
    total_capital: float  # M$ (CAS10-60, includes IDC)
    capital_per_kw: float  # $/kW (total_capital per net electric kW)
    costs: dict[str, float]  # CAS code -> M$ (e.g. "CAS10" -> 16.0)
    power_table: dict[str, float]  # Power flow values (e.g. "p_fus" -> 2300.0)
    sensitivity: dict[
        str, dict[str, float]
    ]  # {"engineering": {...}, "financial": {...}, "costing": {...}}
    overridden: list[str] = field(default_factory=list)  # Keys that were overridden
    params: dict[str, Any] = field(
        default_factory=dict
    )  # Merged forward params (floats plus enums/strings/dicts); sensitivity baselines


def run_costing(inp: FusionTeaInput) -> FusionTeaOutput:
    """Single entry point for fusion-tea pipeline.

    Maps SysML-extracted parameters to CostModel, runs forward costing,
    and returns CAS-code-keyed results.
    """
    concept = ConfinementConcept(inp.concept)
    fuel = Fuel(inp.fuel)
    power_cycle = PowerCycle(inp.power_cycle)

    # Validate customer-level inputs before costing.
    # Engineering overrides (inp.overrides) are intentionally excluded here
    # because they are partial — the YAML template fills the rest inside
    # CostModel.forward(), which runs its own full validation after merge.
    CostingInput(
        concept=concept,
        fuel=fuel,
        net_electric_mw=inp.net_electric_mw,
        availability=inp.availability,
        lifetime_yr=inp.lifetime_yr,
        n_mod=inp.n_mod,
        construction_time_yr=inp.construction_time_yr,
        interest_rate=inp.interest_rate,
        inflation_rate=inp.inflation_rate,
        noak=inp.noak,
        cost_overrides=inp.cost_overrides or {},
        costing_overrides=inp.costing_overrides or {},
        override_reference_mw=inp.override_reference_mw,
    )

    cc = load_costing_constants()
    if inp.costing_overrides:
        cc = cc.replace(**inp.costing_overrides)

    pulsed_conv = None
    if inp.pulsed_conversion:
        pulsed_conv = PulsedConversion(inp.pulsed_conversion)

    laser_drv = None
    if inp.laser_driver_type:
        laser_drv = LaserDriverType(inp.laser_driver_type)

    model = CostModel(
        concept=concept,
        fuel=fuel,
        costing_constants=cc,
        power_cycle=power_cycle,
        pulsed_conversion=pulsed_conv,
        laser_driver_type=laser_drv,
    )
    # construction_time_yr is concept config (concept YAML). Only forward a
    # customer value when one was given; otherwise let the YAML supply it.
    fwd_overrides = dict(inp.overrides)
    if inp.construction_time_yr is not None:
        fwd_overrides["construction_time_yr"] = inp.construction_time_yr
    result = model.forward(
        net_electric_mw=inp.net_electric_mw,
        availability=inp.availability,
        lifetime_yr=inp.lifetime_yr,
        n_mod=inp.n_mod,
        interest_rate=inp.interest_rate,
        inflation_rate=inp.inflation_rate,
        noak=inp.noak,
        cost_overrides=inp.cost_overrides or None,
        override_reference_mw=inp.override_reference_mw,
        **fwd_overrides,
    )

    c = result.costs
    costs = {
        "CAS10": float(c.cas10),
        "CAS21": float(c.cas21),
        "CAS22": float(c.cas22),
        "CAS23": float(c.cas23),
        "CAS24": float(c.cas24),
        "CAS25": float(c.cas25),
        "CAS26": float(c.cas26),
        "CAS27": float(c.cas27),
        "CAS28": float(c.cas28),
        "CAS29": float(c.cas29),
        "CAS20": float(c.cas20),
        "CAS30": float(c.cas30),
        "CAS40": float(c.cas40),
        "CAS50": float(c.cas50),
        "CAS60": float(c.cas60),
        "CAS70": float(c.cas70),
        "CAS71": float(c.cas71),
        "CAS72": float(c.cas72),
        "CAS80": float(c.cas80),
        "CAS90": float(c.cas90),
    }
    # Include CAS22 sub-account detail
    for key, val in result.cas22_detail.items():
        costs[key] = float(val)

    pt = result.power_table
    power_table = {
        "p_fus": float(pt.p_fus),
        "p_th": float(pt.p_th),
        "p_et": float(pt.p_et),
        "p_net": float(pt.p_net),
        "q_sci": float(pt.q_sci),
        "q_eng": float(pt.q_eng),
        "rec_frac": float(pt.rec_frac),
        "e_driver_mj": float(pt.e_driver_mj),
        "e_stored_mj": float(pt.e_stored_mj),
        "f_rep": float(pt.f_rep),
        "f_ch": float(pt.f_ch),
        "p_dee": float(pt.p_dee),
    }

    sens = model.sensitivity(result.params, cost_overrides=inp.cost_overrides or None)

    return FusionTeaOutput(
        lcoe=float(c.lcoe),
        overnight_cost=float(c.overnight_cost),
        total_capital=float(c.total_capital),
        capital_per_kw=float(c.capital_per_kw),
        costs=costs,
        power_table=power_table,
        sensitivity=sens,
        overridden=result.overridden,
        params=dict(result.params),
    )
