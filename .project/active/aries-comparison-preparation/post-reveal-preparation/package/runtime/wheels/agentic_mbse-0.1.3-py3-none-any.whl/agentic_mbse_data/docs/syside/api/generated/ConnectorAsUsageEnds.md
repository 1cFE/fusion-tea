<div id="connectorasusageends" class="section">

# ConnectorAsUsageEnds<a href="#connectorasusageends" class="headerlink" title="Link to this heading"><span class="nerd-font"></span></a>

*<span class="pre">class</span><span class="w"> </span>*<span class="sig-name descname"><span class="pre">ConnectorAsUsageEnds</span></span><a href="#syside.ConnectorAsUsageEnds" class="headerlink" title="Link to this definition"><span class="nerd-font"></span></a>  
<div class="align-center" align="center">

<img src="data:image/svg+xml;base64,PHN2ZyBjbGFzcz0iZ3JhcGh2aXoiIHN0eWxlPSJ3aWR0aDogMTAuMjVyZW07aGVpZ2h0OiAxMS43NXJlbTsiIHZpZXdib3g9IjAuMDAgMC4wMCAxNjQuMDAgMTg4LjAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8ZyBjbGFzcz0iZ3JhcGgiIGlkPSJncmFwaDAiIHRyYW5zZm9ybT0ic2NhbGUoMSAxKSByb3RhdGUoMCkgdHJhbnNsYXRlKDQgMTg0KSI+Cjx0aXRsZT4lMzwvdGl0bGU+CjxnIGNsYXNzPSJub2RlIiBpZD0ibm9kZTEiPgo8dGl0bGU+Q29ubmVjdG9yQXNVc2FnZUVuZHM8L3RpdGxlPgo8ZyBpZD0iYV9ub2RlMSI+PGEgaHJlZj0iI3N5c2lkZS5Db25uZWN0b3JBc1VzYWdlRW5kcyI+Cjxwb2x5Z29uIHBvaW50cz0iMTU1LjUsLTM2IDAuNSwtMzYgMC41LDAgMTU1LjUsMCAxNTUuNSwtMzYiIHN0eWxlPSJmaWxsOiB2YXIoLS1tZC1ncmFwaHZpei1ub2RlLWJnLWNvbG9yKTtzdHJva2U6IHZhcigtLW1kLWdyYXBodml6LW5vZGUtZmctY29sb3IpOyI+PC9wb2x5Z29uPgo8dGV4dCBmb250LWZhbWlseT0iTGV4ZW5kIiBmb250LXNpemU9IjEyLjAwIiBzdHlsZT0iZmlsbDogdmFyKC0tbWQtY29kZS1mZy1jb2xvcik7LS1tZC1ncmFwaHZpei1ob3Zlci1jb2xvcjogdmFyKC0tbWQtZ3JhcGh2aXotYS1ob3Zlci1jb2xvcik7IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiB4PSI3OCIgeT0iLTE0LjIiPkNvbm5lY3RvckFzVXNhZ2VFbmRzPC90ZXh0Pgo8dGl0bGU+c3lzaWRlLkNvbm5lY3RvckFzVXNhZ2VFbmRzPC90aXRsZT48L2E+CjwvZz4KPC9nPgo8ZyBjbGFzcz0ibm9kZSIgaWQ9Im5vZGUyIj4KPHRpdGxlPkNvbm5lY3RvckVuZHNBY2Nlc3NvcjwvdGl0bGU+CjxnIGlkPSJhX25vZGUyIj48YSBocmVmPSIvcHl0aG9uL3YwLjguNC9zeXNpZGUvQ29ubmVjdG9yRW5kc0FjY2Vzc29yLm1kIj4KPHBvbHlnb24gcG9pbnRzPSIxNTYsLTEwOCAwLC0xMDggMCwtNzIgMTU2LC03MiAxNTYsLTEwOCIgc3R5bGU9ImZpbGw6IHZhcigtLW1kLWdyYXBodml6LW5vZGUtYmctY29sb3IpO3N0cm9rZTogdmFyKC0tbWQtZ3JhcGh2aXotbm9kZS1mZy1jb2xvcik7Ij48L3BvbHlnb24+Cjx0ZXh0IGZvbnQtZmFtaWx5PSJMZXhlbmQiIGZvbnQtc2l6ZT0iMTIuMDAiIHN0eWxlPSJmaWxsOiB2YXIoLS1tZC1jb2RlLWZnLWNvbG9yKTstLW1kLWdyYXBodml6LWhvdmVyLWNvbG9yOiB2YXIoLS1tZC1ncmFwaHZpei1hLWhvdmVyLWNvbG9yKTsiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHg9Ijc4IiB5PSItODYuMiI+Q29ubmVjdG9yRW5kc0FjY2Vzc29yPC90ZXh0Pgo8dGl0bGU+c3lzaWRlLkNvbm5lY3RvckVuZHNBY2Nlc3NvcjwvdGl0bGU+PC9hPgo8L2c+CjwvZz4KPGcgY2xhc3M9ImVkZ2UiIGlkPSJlZGdlMSI+Cjx0aXRsZT5Db25uZWN0b3JFbmRzQWNjZXNzb3ItJmd0O0Nvbm5lY3RvckFzVXNhZ2VFbmRzPC90aXRsZT4KPHBhdGggZD0iTTc4LC03MS43Qzc4LC02My45OCA3OCwtNTQuNzEgNzgsLTQ2LjExIiBmaWxsPSJub25lIiBzdHlsZT0ic3Ryb2tlOiB2YXIoLS1tZC1ncmFwaHZpei1lZGdlLWNvbG9yKTsiIC8+Cjxwb2x5Z29uIHBvaW50cz0iODEuNSwtNDYuMSA3OCwtMzYuMSA3NC41LC00Ni4xIDgxLjUsLTQ2LjEiIHN0eWxlPSJmaWxsOiB2YXIoLS1tZC1ncmFwaHZpei1lZGdlLWNvbG9yKTtzdHJva2U6IHZhcigtLW1kLWdyYXBodml6LWVkZ2UtY29sb3IpOyI+PC9wb2x5Z29uPgo8L2c+CjxnIGNsYXNzPSJub2RlIiBpZD0ibm9kZTMiPgo8dGl0bGU+Q2hpbGRyZW5Ob2Rlc1ZpZXc8L3RpdGxlPgo8ZyBpZD0iYV9ub2RlMyI+PGEgaHJlZj0iL3B5dGhvbi92MC44LjQvc3lzaWRlL0NoaWxkcmVuTm9kZXNWaWV3Lm1kIj4KPHBvbHlnb24gcG9pbnRzPSIxNDMsLTE4MCAxMywtMTgwIDEzLC0xNDQgMTQzLC0xNDQgMTQzLC0xODAiIHN0eWxlPSJmaWxsOiB2YXIoLS1tZC1ncmFwaHZpei1ub2RlLWJnLWNvbG9yKTtzdHJva2U6IHZhcigtLW1kLWdyYXBodml6LW5vZGUtZmctY29sb3IpOyI+PC9wb2x5Z29uPgo8dGV4dCBmb250LWZhbWlseT0iTGV4ZW5kIiBmb250LXNpemU9IjEyLjAwIiBzdHlsZT0iZmlsbDogdmFyKC0tbWQtY29kZS1mZy1jb2xvcik7LS1tZC1ncmFwaHZpei1ob3Zlci1jb2xvcjogdmFyKC0tbWQtZ3JhcGh2aXotYS1ob3Zlci1jb2xvcik7IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiB4PSI3OCIgeT0iLTE1OC4yIj5DaGlsZHJlbk5vZGVzVmlldzwvdGV4dD4KPHRpdGxlPnN5c2lkZS5DaGlsZHJlbk5vZGVzVmlldzwvdGl0bGU+PC9hPgo8L2c+CjwvZz4KPGcgY2xhc3M9ImVkZ2UiIGlkPSJlZGdlMiI+Cjx0aXRsZT5DaGlsZHJlbk5vZGVzVmlldy0mZ3Q7Q29ubmVjdG9yRW5kc0FjY2Vzc29yPC90aXRsZT4KPHBhdGggZD0iTTc4LC0xNDMuN0M3OCwtMTM1Ljk4IDc4LC0xMjYuNzEgNzgsLTExOC4xMSIgZmlsbD0ibm9uZSIgc3R5bGU9InN0cm9rZTogdmFyKC0tbWQtZ3JhcGh2aXotZWRnZS1jb2xvcik7IiAvPgo8cG9seWdvbiBwb2ludHM9IjgxLjUsLTExOC4xIDc4LC0xMDguMSA3NC41LC0xMTguMSA4MS41LC0xMTguMSIgc3R5bGU9ImZpbGw6IHZhcigtLW1kLWdyYXBodml6LWVkZ2UtY29sb3IpO3N0cm9rZTogdmFyKC0tbWQtZ3JhcGh2aXotZWRnZS1jb2xvcik7Ij48L3BvbHlnb24+CjwvZz4KPC9nPgo8L3N2Zz4=" class="graphviz" />

</div>

<span class="sd-summary-text">Members defined in <a href="#syside.ConnectorAsUsageEnds" class="reference internal" title="syside.ConnectorAsUsageEnds"><span class="pre"><code class="sourceCode python">ConnectorAsUsageEnds</code></span></a> (0 members)</span><span class="sd-summary-state-marker sd-summary-chevron-right"><img src="data:image/svg+xml;base64,PHN2ZyBhcmlhLWhpZGRlbj0idHJ1ZSIgY2xhc3M9InNkLW9jdGljb24gc2Qtb2N0aWNvbi1jaGV2cm9uLXJpZ2h0IiBoZWlnaHQ9IjEuNWVtIiB2ZXJzaW9uPSIxLjEiIHZpZXdib3g9IjAgMCAyNCAyNCIgd2lkdGg9IjEuNWVtIj48cGF0aCBkPSJNOC43MiAxOC43OGEuNzUuNzUgMCAwIDEgMC0xLjA2TDE0LjQ0IDEyIDguNzIgNi4yOGEuNzUxLjc1MSAwIDAgMSAuMDE4LTEuMDQyLjc1MS43NTEgMCAwIDEgMS4wNDItLjAxOGw2LjI1IDYuMjVhLjc1Ljc1IDAgMCAxIDAgMS4wNmwtNi4yNSA2LjI1YS43NS43NSAwIDAgMS0xLjA2IDBaIiAvPjwvc3ZnPg==" class="sd-octicon sd-octicon-chevron-right" /></span>

<div class="sd-summary-content sd-card-body docutils">

</div>

<span class="sd-summary-text">Members inherited from <a href="/python/v0.8.4/syside/ConnectorEndsAccessor.md" class="reference internal" title="syside.ConnectorEndsAccessor"><span class="pre"><code class="sourceCode python">ConnectorEndsAccessor</code></span></a> (8 members)</span><span class="sd-summary-state-marker sd-summary-chevron-right"><img src="data:image/svg+xml;base64,PHN2ZyBhcmlhLWhpZGRlbj0idHJ1ZSIgY2xhc3M9InNkLW9jdGljb24gc2Qtb2N0aWNvbi1jaGV2cm9uLXJpZ2h0IiBoZWlnaHQ9IjEuNWVtIiB2ZXJzaW9uPSIxLjEiIHZpZXdib3g9IjAgMCAyNCAyNCIgd2lkdGg9IjEuNWVtIj48cGF0aCBkPSJNOC43MiAxOC43OGEuNzUuNzUgMCAwIDEgMC0xLjA2TDE0LjQ0IDEyIDguNzIgNi4yOGEuNzUxLjc1MSAwIDAgMSAuMDE4LTEuMDQyLjc1MS43NTEgMCAwIDEgMS4wNDItLjAxOGw2LjI1IDYuMjVhLjc1Ljc1IDAgMCAxIDAgMS4wNmwtNi4yNSA2LjI1YS43NS43NSAwIDAgMS0xLjA2IDBaIiAvPjwvc3ZnPg==" class="sd-octicon sd-octicon-chevron-right" /></span>

<div class="sd-summary-content sd-card-body docutils">

<div class="pst-scrollable-table-container">

|  |  |  |  |
|----|----|----|----|
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ConnectorEndsAccessor.md" class="reference internal" title="syside.ConnectorEndsAccessor.modifiable"><span class="pre"><code class="sourceCode python">modifiable</code></span></a> | <span class="pre">`R`</span> | Returns <span class="pre">`True`</span> if the contents of this accessor can be modified. In such a case, <span class="pre">`try_`</span> methods will return values, and corresponding modification methods will not raise <span class="pre">`ValueErrors`</span>. |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ConnectorEndsAccessor.md" class="reference internal" title="syside.ConnectorEndsAccessor.append"><span class="pre"><code class="sourceCode python">append</code></span></a> |  | Same as <span class="pre">`try_append`</span> but will raise <span class="pre">`ValueError`</span> if the contents cannot be modified. |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ConnectorEndsAccessor.md" class="reference internal" title="syside.ConnectorEndsAccessor.clear"><span class="pre"><code class="sourceCode python">clear</code></span></a> |  | Clear the contents accessed by this accessor. Does nothing if the contents cannot be modified. |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ConnectorEndsAccessor.md" class="reference internal" title="syside.ConnectorEndsAccessor.erase"><span class="pre"><code class="sourceCode python">erase</code></span></a> |  | Erase <span class="pre">`Feature`</span> at the specified index. Raises <span class="pre">`IndexError`</span> if the index is out of bounds. |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ConnectorEndsAccessor.md" class="reference internal" title="syside.ConnectorEndsAccessor.extract"><span class="pre"><code class="sourceCode python">extract</code></span></a> |  | Extract <span class="pre">`Feature`</span> at the specified index. Raises <span class="pre">`IndexError`</span> if the index is out of bounds. |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ConnectorEndsAccessor.md" class="reference internal" title="syside.ConnectorEndsAccessor.insert"><span class="pre"><code class="sourceCode python">insert</code></span></a> |  | Same as <span class="pre">`insert`</span> but will raise <span class="pre">`ValueError`</span> if the contents cannot be modified. |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ConnectorEndsAccessor.md" class="reference internal" title="syside.ConnectorEndsAccessor.try_append"><span class="pre"><code class="sourceCode python">try_append</code></span></a> |  | Try appending a new <span class="pre">`Feature`</span>. Ownership constraints apply. |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ConnectorEndsAccessor.md" class="reference internal" title="syside.ConnectorEndsAccessor.try_insert"><span class="pre"><code class="sourceCode python">try_insert</code></span></a> |  | Try inserting a new <span class="pre">`Feature`</span> at the specified index. Ownership constraints apply. |

</div>

</div>

<span class="sd-summary-text">Members inherited from <a href="/python/v0.8.4/syside/ChildrenNodesView.md" class="reference internal" title="syside.ChildrenNodesView"><span class="pre"><code class="sourceCode python">ChildrenNodesView</code></span></a> (6 members)</span><span class="sd-summary-state-marker sd-summary-chevron-right"><img src="data:image/svg+xml;base64,PHN2ZyBhcmlhLWhpZGRlbj0idHJ1ZSIgY2xhc3M9InNkLW9jdGljb24gc2Qtb2N0aWNvbi1jaGV2cm9uLXJpZ2h0IiBoZWlnaHQ9IjEuNWVtIiB2ZXJzaW9uPSIxLjEiIHZpZXdib3g9IjAgMCAyNCAyNCIgd2lkdGg9IjEuNWVtIj48cGF0aCBkPSJNOC43MiAxOC43OGEuNzUuNzUgMCAwIDEgMC0xLjA2TDE0LjQ0IDEyIDguNzIgNi4yOGEuNzUxLjc1MSAwIDAgMSAuMDE4LTEuMDQyLjc1MS43NTEgMCAwIDEgMS4wNDItLjAxOGw2LjI1IDYuMjVhLjc1Ljc1IDAgMCAxIDAgMS4wNmwtNi4yNSA2LjI1YS43NS43NSAwIDAgMS0xLjA2IDBaIiAvPjwvc3ZnPg==" class="sd-octicon sd-octicon-chevron-right" /></span>

<div class="sd-summary-content sd-card-body docutils">

<div class="pst-scrollable-table-container">

|  |  |  |  |
|----|----|----|----|
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ChildrenNodesView.md" class="reference internal" title="syside.ChildrenNodesView.elements"><span class="pre"><code class="sourceCode python">elements</code></span></a> | <span class="pre">`R`</span> | The related elements in this container. |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ChildrenNodesView.md" class="reference internal" title="syside.ChildrenNodesView.relationships"><span class="pre"><code class="sourceCode python">relationships</code></span></a> | <span class="pre">`R`</span> | The relationships in this container. |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ChildrenNodesView.md" class="reference internal" title="syside.ChildrenNodesView.__bool__"><span class="pre"><code class="sourceCode python"><span class="fu">__bool__</span></code></span></a> |  |  |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ChildrenNodesView.md" class="reference internal" title="syside.ChildrenNodesView.__getitem__"><span class="pre"><code class="sourceCode python"><span class="fu">__getitem__</span></code></span></a> |  |  |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ChildrenNodesView.md" class="reference internal" title="syside.ChildrenNodesView.__len__"><span class="pre"><code class="sourceCode python"><span class="fu">__len__</span></code></span></a> |  |  |
| <span class="nerd-font"></span> | <a href="/python/v0.8.4/syside/ChildrenNodesView.md" class="reference internal" title="syside.ChildrenNodesView.at"><span class="pre"><code class="sourceCode python">at</code></span></a> |  |  |

</div>

</div>

<span class="sd-summary-text"><span class="nerd-font"></span> Used in</span><span class="sd-summary-state-marker sd-summary-chevron-right"><img src="data:image/svg+xml;base64,PHN2ZyBhcmlhLWhpZGRlbj0idHJ1ZSIgY2xhc3M9InNkLW9jdGljb24gc2Qtb2N0aWNvbi1jaGV2cm9uLXJpZ2h0IiBoZWlnaHQ9IjEuNWVtIiB2ZXJzaW9uPSIxLjEiIHZpZXdib3g9IjAgMCAyNCAyNCIgd2lkdGg9IjEuNWVtIj48cGF0aCBkPSJNOC43MiAxOC43OGEuNzUuNzUgMCAwIDEgMC0xLjA2TDE0LjQ0IDEyIDguNzIgNi4yOGEuNzUxLjc1MSAwIDAgMSAuMDE4LTEuMDQyLjc1MS43NTEgMCAwIDEgMS4wNDItLjAxOGw2LjI1IDYuMjVhLjc1Ljc1IDAgMCAxIDAgMS4wNmwtNi4yNSA2LjI1YS43NS43NSAwIDAgMS0xLjA2IDBaIiAvPjwvc3ZnPg==" class="sd-octicon sd-octicon-chevron-right" /></span>

<div class="sd-summary-content sd-card-body docutils">

- <a href="/python/v0.8.4/syside/ConnectorAsUsage.md" class="reference internal" title="syside.ConnectorAsUsage"><span class="pre"><code class="sourceCode python">syside.ConnectorAsUsage</code></span></a>

  - <a href="/python/v0.8.4/syside/ConnectorAsUsage.md" class="reference internal" title="syside.ConnectorAsUsage.declared_ends"><span class="pre"><code class="sourceCode python">declared_ends</code></span></a>

</div>

</div>
