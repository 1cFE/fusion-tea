"""Command-line interface for agentic-mbse."""

import argparse
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path

import tomllib
from dotenv import load_dotenv

from agentic_mbse.extraction.base import compute_source_hash
from agentic_mbse.validation import EXIT_FAILURE, EXIT_SUCCESS, run_all_checks

# Commands available for installation
MBSE_COMMANDS = [
    "analyze-models.md",
    "audit-models.md",
    "backlog.md",
    "design-model.md",
    "formalize-intent.md",
    "implement-model.md",
    "manage-sources.md",
    "onboard.md",
    "orchestrate-modeling.md",
    "plan-model.md",
    "quick-model.md",
    "research.md",
    "review-model.md",
    "spec-model.md",
    "status.md",
]

# Agents available for installation
MBSE_AGENTS = [
    "python-debugger.md",
    "kerml-expert.md",
    "sysml-expert.md",
    "syside-expert.md",
    "sysmlv2-validator.md",
]

# Skills available for installation (directories, not files)
MBSE_SKILLS = [
    "epic-decomposition",
    "model-validation",
    "pdf-analysis",
    "project-structure",
    "python-debugger",
    "record-learning",
    "requirements-tracking",
    "source-traceability",
    "sysml-conventions",
    "toolkit-awareness",
]

# Hooks available for installation
MBSE_HOOKS = [
    "ruff-format.sh",
]

# Project templates split by ownership:
# - USER_OWNED: Only created once, never auto-updated (user customizes these)
# - TOOL_OWNED: Auto-updated on every init (tool manages these)
USER_OWNED_TEMPLATES = [
    ("README.md.template", "README.md"),
    ("OVERVIEW.md.template", "modeling_project/OVERVIEW.md"),
    ("BACKLOG.md.template", "work/BACKLOG.md"),
    ("RAW_LEARNINGS.md.template", "work/learnings/RAW_LEARNINGS.md"),
    ("KNOWLEDGE.md.template", "knowledge/KNOWLEDGE.md"),
    ("ARCHITECTURE.md.template", "modeling_project/ARCHITECTURE.md"),
    ("REQUIREMENTS.md.template", "modeling_project/REQUIREMENTS.md"),
    ("VALIDATION_MATRIX.md.template", "modeling_project/VALIDATION_MATRIX.md"),
    ("test_models_example.py.template", "tests/models/test_example.py"),
    ("conftest.py.template", "tests/conftest.py"),
]

TOOL_OWNED_TEMPLATES = [
    ("MODELING_GUIDE.md.template", "modeling_project/MODELING_GUIDE.md"),
    ("MODELING_PROCESS.md.template", "modeling_project/MODELING_PROCESS.md"),
    ("EPIC_GUIDE.md.template", "work/EPIC_GUIDE.md"),
    ("epic_template.md.template", "work/backlog/epic_template.md"),
]

# Combined for backwards compatibility
PROJECT_TEMPLATES = USER_OWNED_TEMPLATES + TOOL_OWNED_TEMPLATES

# Paths to add to .gitignore in dev mode (symlinks are machine-specific)
DEV_MODE_GITIGNORE_PATHS = [
    "# Tool-owned files (managed by agentic-mbse init --dev)",
    ".claude/commands/",
    ".claude/agents/",
    ".claude/skills/",
    ".claude/hooks/",
    ".claude/.tool-hashes.json",
    "modeling_project/MODELING_GUIDE.md",
    "modeling_project/MODELING_PROCESS.md",
    "work/EPIC_GUIDE.md",
    "work/backlog/epic_template.md",
]

# Hash file for tracking tool-owned file modifications
HASH_FILE = ".claude/.tool-hashes.json"


def _get_data_root() -> Path:
    """Get root path for bundled data (claude/, docs/, templates).

    Supports two installation modes:
    1. Source checkout: agentic-mbse/src/agentic_mbse/cli/__init__.py
       → Data at: agentic-mbse/claude/, agentic-mbse/docs/
    2. Pip install: site-packages/agentic_mbse/cli/__init__.py
       → Data at: site-packages/agentic_mbse_data/claude/, etc.
    """
    # Try source checkout path first (development mode)
    source_root = Path(__file__).parent.parent.parent.parent
    if (source_root / "claude").exists():
        return source_root

    # Fallback to pip-installed package data location
    pip_data_root = Path(__file__).parent.parent.parent / "agentic_mbse_data"
    if pip_data_root.exists():
        return pip_data_root

    # Last resort: return source root and let caller handle missing files
    return source_root


def get_commands_dir() -> Path:
    """Get path to bundled commands directory."""
    return _get_data_root() / "claude" / "commands"


def get_template_path() -> Path:
    """Get path to SOURCE_INDEX.md template."""
    return _get_data_root() / "SOURCE_INDEX.md.template"


def get_agents_dir() -> Path:
    """Get path to bundled agents directory."""
    return _get_data_root() / "claude" / "agents"


def get_skills_dir() -> Path:
    """Get path to bundled skills directory."""
    return _get_data_root() / "claude" / "skills"


def get_hooks_dir() -> Path:
    """Get path to bundled hooks directory."""
    return _get_data_root() / "claude" / "hooks"


def get_docs_dir() -> Path:
    """Get path to bundled docs directory."""
    return _get_data_root() / "docs"


def get_project_templates_dir() -> Path:
    """Get path to bundled project templates directory."""
    return _get_data_root() / "project_templates"


def find_project_root() -> Path | None:
    """Walk up from CWD to find a project root.

    Looks for work/BACKLOG.md (primary) or .claude/ (fallback).
    Returns None if neither found.
    """
    current = Path.cwd()
    while True:
        if (current / "work" / "BACKLOG.md").exists():
            return current
        if (current / ".claude").exists():
            return current
        parent = current.parent
        if parent == current:
            return None
        current = parent


def cmd_status(args) -> int:
    """Show project status dashboard."""
    from agentic_mbse.cli.pm_cli import _print_warnings

    project_root = find_project_root()
    if project_root is None:
        print(
            "Error: Not inside a project (no work/BACKLOG.md found)",
            file=sys.stderr,
        )
        return EXIT_FAILURE

    if args.json_output:
        from agentic_mbse.pm.parser import parse_requirements, parse_validation_matrix
        from agentic_mbse.pm.state import derive_project_state

        warnings = []
        state_result = derive_project_state(project_root)
        warnings.extend(state_result.warnings)
        req_result = parse_requirements(project_root / "modeling_project" / "REQUIREMENTS.md")
        warnings.extend(req_result.warnings)
        val_result = parse_validation_matrix(
            project_root / "modeling_project" / "VALIDATION_MATRIX.md"
        )
        warnings.extend(val_result.warnings)

        _print_warnings(warnings)

        output = {
            "project": project_root.name,
            "state": state_result.data.model_dump(mode="json"),
            "requirements": [r.model_dump(mode="json") for r in req_result.data],
            "validation": [v.model_dump(mode="json") for v in val_result.data],
        }
        print(json.dumps(output, indent=2))
    else:
        from agentic_mbse.pm.dashboard import generate_dashboard

        result = generate_dashboard(project_root)
        _print_warnings(result.warnings)
        print(result.markdown)

    return EXIT_SUCCESS


def _to_claude_permission_path(abs_path: str) -> str:
    """Convert absolute path to Claude Code permission format.

    Claude Code permission paths are format-sensitive:
    - `/path` = relative to settings.json (NOT absolute!)
    - `//path` = absolute filesystem path
    - `~/path` = from $HOME

    This function converts absolute paths to `~` format when under $HOME
    for portability, or `//` prefix otherwise.
    """
    import os

    home = os.path.expanduser("~")
    if abs_path.startswith(home + "/"):
        # Convert /home/user/foo to ~/foo
        return "~" + abs_path[len(home) :]
    elif abs_path == home:
        return "~"
    else:
        # Use / prefix for absolute paths not under home
        # (Claude interprets //path as absolute filesystem path)
        return "/" + abs_path


def _detect_editable_deps(target: Path) -> list[str]:
    """Detect editable dependencies from pyproject.toml.

    Parses [tool.uv.sources] section to find editable paths.
    Returns list of absolute paths that should be added to Claude settings.
    """
    pyproject = target / "pyproject.toml"
    if not pyproject.exists():
        return []

    try:
        data = tomllib.loads(pyproject.read_text())
        sources = data.get("tool", {}).get("uv", {}).get("sources", {})
        paths = []
        for _name, config in sources.items():
            if isinstance(config, dict) and config.get("editable"):
                rel_path = config.get("path", "")
                if rel_path:
                    abs_path = (target / rel_path).resolve()
                    if abs_path.exists():
                        paths.append(str(abs_path))
        return paths
    except Exception:
        return []


def _check_dev_mode_prerequisites(data_root: Path) -> tuple[bool, str | None]:
    """Check if dev mode can be used.

    Returns:
        (can_use, error_message) - error_message is None if can_use is True
    """
    # Check Windows
    if platform.system() == "Windows":
        return False, "Dev mode is not supported on Windows (symlinks require admin privileges)"

    # Check source checkout (claude/ directory exists at root)
    if not (data_root / "claude").exists():
        return False, (
            "Dev mode requires a source checkout of agentic-mbse.\n"
            "Pip-installed packages cannot use dev mode.\n"
            "Clone the repo and install with: pip install -e /path/to/agentic-mbse"
        )

    return True, None


def _get_git_commit() -> str:
    """Get short git commit hash of agentic-mbse source.

    Returns 'unknown' if not in a git repo or git not available.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            cwd=_get_data_root(),  # Run in agentic-mbse source dir
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return "unknown"


def _load_tool_hashes(target: Path) -> dict | None:
    """Load hash file, return None if doesn't exist."""
    hash_path = target / HASH_FILE
    if not hash_path.exists():
        return None
    return json.loads(hash_path.read_text())


def _save_tool_hashes(target: Path, hashes: dict) -> None:
    """Save hash file."""
    hash_path = target / HASH_FILE
    hash_path.parent.mkdir(parents=True, exist_ok=True)
    hash_path.write_text(json.dumps(hashes, indent=2) + "\n")


def _check_modification(path: Path, stored_hashes: dict | None, relative_path: str) -> bool:
    """Check if file was modified since install.

    Returns True if file exists AND has been modified from installed version.
    Returns False if file doesn't exist OR matches stored hash.
    """
    if not path.exists():
        return False
    if stored_hashes is None:
        # First time tracking - treat as not modified
        # (backwards compatibility: existing installs without hashes)
        return False
    stored_hash = stored_hashes.get("files", {}).get(relative_path)
    if stored_hash is None:
        # File not in hash store - new file type, treat as not modified
        return False
    current_hash = compute_source_hash(path)
    return current_hash != stored_hash


def _backup_file(path: Path) -> Path:
    """Create backup of file with .backup extension.

    If .backup exists, uses .backup.1, .backup.2, etc.
    Returns path to backup file.
    """
    backup_path = path.with_suffix(path.suffix + ".backup")
    counter = 1
    while backup_path.exists():
        backup_path = path.with_suffix(f"{path.suffix}.backup.{counter}")
        counter += 1
    shutil.copy(path, backup_path)
    return backup_path


def _prompt_for_modified_file(path: str) -> str:
    """Prompt user for action on modified file.

    Returns: 'skip', 'backup', 'overwrite', 'skip_all', 'overwrite_all'
    """
    print(f"\nModified: {path}")
    print("  This file has local modifications that will be lost if updated.")
    print("  Options:")
    print("    [s]kip      - Keep your version")
    print("    [b]ackup    - Save to .backup, then update")
    print("    [o]verwrite - Replace with new version")
    print("    [S]kip all  - Skip all modified files")
    print("    [O]verwrite all - Update all (like --force)")

    while True:
        choice = input("  Choice [s/b/o/S/O]: ").strip()
        if choice == "s":
            return "skip"
        elif choice == "b":
            return "backup"
        elif choice == "o":
            return "overwrite"
        elif choice == "S":
            return "skip_all"
        elif choice == "O":
            return "overwrite_all"
        else:
            print("  Invalid choice. Please enter s, b, o, S, or O.")


def _install_file_with_hash(
    src: Path,
    dst: Path,
    is_dev_mode: bool,
    was_modified: bool = False,
    user_action: str = "overwrite",
) -> tuple[str, str | None]:
    """Install a file by copying or symlinking, returning hash.

    Args:
        src: Source file path
        dst: Destination file path
        is_dev_mode: If True, create symlink; if False, copy
        was_modified: If True, file had local modifications
        user_action: 'skip', 'backup', or 'overwrite'

    Returns:
        Tuple of (action_taken, content_hash_or_none)
        - action_taken: "created", "updated", "symlinked", "skipped", "backed_up_and_updated"
        - content_hash_or_none: SHA256 of installed content (None if symlinked or skipped)
    """
    existed = dst.exists() or dst.is_symlink()

    # Handle modified file based on user choice
    if was_modified and user_action == "skip":
        return ("skipped", None)

    if was_modified and user_action == "backup":
        backup_path = _backup_file(dst)
        print(f"    Backed up to: {backup_path.name}")

    # Remove existing file or symlink before creating new one
    if existed:
        dst.unlink()

    if is_dev_mode:
        dst.symlink_to(src.resolve())
        return ("re-symlinked" if existed else "symlinked", None)
    else:
        shutil.copy(src, dst)
        content_hash = compute_source_hash(dst)
        if was_modified and user_action == "backup":
            return ("backed_up_and_updated", content_hash)
        return ("updated" if existed else "created", content_hash)


def _install_file(src: Path, dst: Path, is_dev_mode: bool) -> str:
    """Install a file by copying or symlinking.

    Args:
        src: Source file path
        dst: Destination file path
        is_dev_mode: If True, create symlink; if False, copy

    Returns:
        Action taken: "created", "updated", "symlinked", or "re-symlinked"
    """
    existed = dst.exists() or dst.is_symlink()

    # Remove existing file or symlink before creating new one
    if existed:
        dst.unlink()

    if is_dev_mode:
        dst.symlink_to(src.resolve())
        return "re-symlinked" if existed else "symlinked"
    else:
        shutil.copy(src, dst)
        return "updated" if existed else "created"


def _install_directory(src: Path, dst: Path, is_dev_mode: bool) -> str:
    """Install a directory by copying or symlinking.

    Args:
        src: Source directory path
        dst: Destination directory path
        is_dev_mode: If True, create symlink; if False, copy tree

    Returns:
        Action taken: "created", "updated", "symlinked", or "re-symlinked"
    """
    existed = dst.exists() or dst.is_symlink()

    if existed:
        if dst.is_symlink():
            dst.unlink()
        else:
            shutil.rmtree(dst)

    if is_dev_mode:
        dst.symlink_to(src.resolve())
        return "re-symlinked" if existed else "symlinked"
    else:
        shutil.copytree(src, dst, dirs_exist_ok=True)
        return "updated" if existed else "created"


def _update_gitignore_for_dev_mode(target: Path) -> bool:
    """Add tool-owned paths to .gitignore for dev mode.

    Symlinks use absolute paths pointing to developer's local agentic-mbse
    checkout. If committed to git, other developers would have broken symlinks.
    This function adds tool-owned paths to .gitignore to prevent that.

    Returns True if .gitignore was modified, False if paths already present.
    """
    gitignore_path = target / ".gitignore"

    # Read existing content
    existing_content = ""
    if gitignore_path.exists():
        existing_content = gitignore_path.read_text()

    # Check if already has dev mode section (idempotent)
    marker = DEV_MODE_GITIGNORE_PATHS[0]
    if marker in existing_content:
        return False

    # Append dev mode paths
    new_section = "\n" + "\n".join(DEV_MODE_GITIGNORE_PATHS) + "\n"
    gitignore_path.write_text(existing_content.rstrip() + new_section)
    return True


# Load environment variables from .env file (for SYSIDE_LICENSE_KEY, etc.)
load_dotenv()

__all__ = ["main"]


def cmd_validate(args: argparse.Namespace) -> int:
    """Run validation on models."""
    if not Path(args.path).exists():
        print(f"Error: Path does not exist: {args.path}")
        return EXIT_FAILURE

    result = run_all_checks(
        models_path=args.path,
        fail_fast=not args.complete,
        specific_level=args.level,
        verbose=args.verbose,
    )
    return EXIT_SUCCESS if result.overall_success else EXIT_FAILURE


def cmd_init(args: argparse.Namespace) -> int:
    """Initialize project with agentic-mbse configuration.

    Creates:
    - .gitignore (standard Python ignores including .env) [user-owned]
    - knowledge/SOURCE_INDEX.md (domain knowledge discovery) [user-owned]
    - knowledge/KNOWLEDGE.md (domain insight registry) [user-owned]
    - modeling_project/ structure (OVERVIEW, ARCHITECTURE, REQUIREMENTS, etc.) [mixed]
    - work/ structure (BACKLOG, EPIC_GUIDE, epic template, active, completed, etc.) [mixed]
    - data/traceability_matrix.csv (element traceability) [user-owned]
    - .claude/commands/ with MBSE commands [tool-owned]
    - .claude/agents/ with AI agents [tool-owned]
    - .claude/skills/ with skills [tool-owned]
    - .claude/hooks/ with hooks [tool-owned]
    - .claude/settings.json with read permissions [user-owned]
    - tests/ structure with example test files [user-owned]

    File ownership behavior:
    - Tool-owned files are always updated (to get latest versions)
    - User-owned files are skipped if they exist (preserves customizations)

    Use --force to overwrite ALL files including user-owned ones.
    """
    target = Path(args.path or ".").resolve()

    if not target.exists():
        print(f"Error: Directory does not exist: {target}", file=sys.stderr)
        print("Create the directory first, or specify a valid path.", file=sys.stderr)
        return EXIT_FAILURE

    # Check dev mode prerequisites
    is_dev_mode = getattr(args, "dev", False)
    data_root = _get_data_root()

    if is_dev_mode:
        can_use, error_msg = _check_dev_mode_prerequisites(data_root)
        if not can_use:
            print(f"Error: {error_msg}", file=sys.stderr)
            return EXIT_FAILURE

    # Track what happens for summary
    created: list[str] = []  # New files (didn't exist before)
    updated: list[str] = []  # Tool-owned files refreshed
    skipped: list[str] = []  # User-owned files preserved
    symlinked: list[str] = []  # Dev mode symlinks
    backed_up: list[str] = []  # Modified files that were backed up

    # === Load existing hashes and detect modifications ===
    stored_hashes = _load_tool_hashes(target) if not is_dev_mode else None
    new_hashes: dict[str, str] = {}  # Will collect hashes during install

    # Build list of tool-owned files that have been modified
    modified_files: list[str] = []
    if not is_dev_mode and not args.force and stored_hashes:
        # Check commands
        for cmd in MBSE_COMMANDS:
            rel_path = f".claude/commands/{cmd}"
            if _check_modification(target / rel_path, stored_hashes, rel_path):
                modified_files.append(rel_path)
        # Check agents
        for agent in MBSE_AGENTS:
            rel_path = f".claude/agents/{agent}"
            if _check_modification(target / rel_path, stored_hashes, rel_path):
                modified_files.append(rel_path)
        # Check hooks
        for hook in MBSE_HOOKS:
            rel_path = f".claude/hooks/{hook}"
            if _check_modification(target / rel_path, stored_hashes, rel_path):
                modified_files.append(rel_path)
        # Check tool-owned templates
        for _, dest_path in TOOL_OWNED_TEMPLATES:
            if _check_modification(target / dest_path, stored_hashes, dest_path):
                modified_files.append(dest_path)

    # Prompt user for modified files
    user_decisions: dict[str, str] = {}
    default_action: str | None = None

    if modified_files:
        print(f"\n{len(modified_files)} tool-owned file(s) have local modifications:")
        for f in modified_files:
            print(f"  - {f}")

        for f in modified_files:
            if default_action:
                user_decisions[f] = default_action
            else:
                action = _prompt_for_modified_file(f)
                if action == "skip_all":
                    default_action = "skip"
                    user_decisions[f] = "skip"
                elif action == "overwrite_all":
                    default_action = "overwrite"
                    user_decisions[f] = "overwrite"
                else:
                    user_decisions[f] = action

    # === Create .gitignore with standard Python ignores ===
    gitignore_path = target / ".gitignore"
    if gitignore_path.exists() and not args.force:
        skipped.append(".gitignore")
    else:
        gitignore_content = """\
# Environment and secrets
.env
.env.*

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Virtual environments
.venv/
venv/
ENV/

# Testing and coverage
.pytest_cache/
.coverage
htmlcov/
.tox/
.nox/

# Type checking
.mypy_cache/

# Linting
.ruff_cache/

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# agentic-mbse tool state (machine-local)
.claude/.tool-hashes.json
"""
        gitignore_path.write_text(gitignore_content)
        created.append(".gitignore")

    # === Create knowledge/SOURCE_INDEX.md from template ===
    source_index_path = target / "knowledge" / "SOURCE_INDEX.md"
    template_path = get_template_path()

    if source_index_path.exists() and not args.force:
        skipped.append("knowledge/SOURCE_INDEX.md")
    else:
        source_index_path.parent.mkdir(parents=True, exist_ok=True)
        if template_path.exists():
            shutil.copy(template_path, source_index_path)
        else:
            # Fallback: create minimal template inline
            minimal_template = """# Source Index

This file tells MBSE commands where to find domain knowledge sources.

## Primary Sources

(No primary sources configured yet - commands will ask for references as needed)

## How This File Is Used

MBSE commands read this file to discover what reference sources exist.
Edit this file to add your domain-specific sources.
"""
            source_index_path.write_text(minimal_template)
        created.append("knowledge/SOURCE_INDEX.md")

    # === Create .claude/commands/ and install commands (TOOL-OWNED) ===
    commands_dir = target / ".claude" / "commands"
    commands_dir.mkdir(parents=True, exist_ok=True)

    source_commands = get_commands_dir()
    for cmd in MBSE_COMMANDS:
        src = source_commands / cmd
        dst = commands_dir / cmd
        rel_path = f".claude/commands/{cmd}"
        if src.exists():
            was_modified = rel_path in modified_files
            user_action = user_decisions.get(rel_path, "overwrite")
            action, content_hash = _install_file_with_hash(
                src, dst, is_dev_mode, was_modified, user_action
            )
            if content_hash:
                new_hashes[rel_path] = content_hash
            if "symlink" in action:
                symlinked.append(rel_path)
            elif action == "skipped":
                skipped.append(rel_path)
            elif action == "backed_up_and_updated":
                backed_up.append(rel_path)
            elif action == "updated":
                updated.append(rel_path)
            else:
                created.append(rel_path)

    # === Install agents with path substitution (TOOL-OWNED) ===
    agents_dir = target / ".claude" / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)

    docs_path = get_docs_dir()
    source_agents = get_agents_dir()
    for agent in MBSE_AGENTS:
        src = source_agents / agent
        dst = agents_dir / agent
        rel_path = f".claude/agents/{agent}"
        if src.exists():
            if is_dev_mode:
                # Symlink directly - placeholders remain in source
                action = _install_file(src, dst, is_dev_mode=True)
                symlinked.append(rel_path)
            else:
                # Check modification and get user decision
                was_modified = rel_path in modified_files
                user_action = user_decisions.get(rel_path, "overwrite")

                if was_modified and user_action == "skip":
                    skipped.append(rel_path)
                    continue

                existed = dst.exists() or dst.is_symlink()

                if was_modified and user_action == "backup":
                    backup_path = _backup_file(dst)
                    print(f"    Backed up to: {backup_path.name}")

                if existed:
                    dst.unlink()

                # Copy with placeholder substitution
                content = src.read_text()
                content = content.replace("{SYSML_DOCS_PATH}", f"{docs_path}/sysmlv2")
                content = content.replace("{SYSIDE_DOCS_PATH}", f"{docs_path}/syside")
                dst.write_text(content)

                # Compute and store hash
                new_hashes[rel_path] = compute_source_hash(dst)

                if was_modified and user_action == "backup":
                    backed_up.append(rel_path)
                elif existed:
                    updated.append(rel_path)
                else:
                    created.append(rel_path)

    # === Install skills (TOOL-OWNED) ===
    skills_dir = target / ".claude" / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)

    source_skills = get_skills_dir()
    for skill in MBSE_SKILLS:
        src = source_skills / skill
        dst = skills_dir / skill
        if src.exists() and src.is_dir():
            action = _install_directory(src, dst, is_dev_mode)
            if "symlink" in action:
                symlinked.append(f".claude/skills/{skill}/")
            elif action == "updated":
                updated.append(f".claude/skills/{skill}/")
            else:
                created.append(f".claude/skills/{skill}/")

    # === Install hooks (TOOL-OWNED) ===
    hooks_dir = target / ".claude" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)

    source_hooks = get_hooks_dir()
    for hook in MBSE_HOOKS:
        src = source_hooks / hook
        dst = hooks_dir / hook
        rel_path = f".claude/hooks/{hook}"
        if src.exists():
            was_modified = rel_path in modified_files
            user_action = user_decisions.get(rel_path, "overwrite")
            action, content_hash = _install_file_with_hash(
                src, dst, is_dev_mode, was_modified, user_action
            )
            # Preserve execute permission (symlinks inherit from target)
            if not is_dev_mode and action not in ("skipped",):
                dst.chmod(src.stat().st_mode)
            if content_hash:
                new_hashes[rel_path] = content_hash
            if "symlink" in action:
                symlinked.append(rel_path)
            elif action == "skipped":
                skipped.append(rel_path)
            elif action == "backed_up_and_updated":
                backed_up.append(rel_path)
            elif action == "updated":
                updated.append(rel_path)
            else:
                created.append(rel_path)

    # === Create project structure (4-directory architecture) ===
    for subdir in [
        "knowledge",
        "knowledge/research/pending",
        "knowledge/research/approved",
        "knowledge/research/impacts",
        "knowledge/sources",
        "modeling_project",
        "modeling_project/intent",
        "work",
        "work/backlog",
        "work/active",
        "work/completed",
        "work/analysis",
        "work/learnings",
        "data",
        "models/library",
        "models/designs",
    ]:
        (target / subdir).mkdir(parents=True, exist_ok=True)

    # === Create tests/models/ directory for model regression tests ===
    tests_models_dir = target / "tests" / "models"
    tests_models_dir.mkdir(parents=True, exist_ok=True)

    templates_dir = get_project_templates_dir()

    # === User-owned templates (skip if exists) ===
    for template_name, dest_path in USER_OWNED_TEMPLATES:
        src = templates_dir / template_name
        dst = target / dest_path
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and not args.force:
            skipped.append(dest_path)
            continue
        if src.exists():
            shutil.copy(src, dst)
            created.append(dest_path)

    # === Install traceability matrix CSV (USER-OWNED) ===
    csv_src = templates_dir / "data" / "traceability_matrix.csv"
    csv_dst = target / "data" / "traceability_matrix.csv"
    if csv_dst.exists() and not args.force:
        skipped.append("data/traceability_matrix.csv")
    elif csv_src.exists():
        shutil.copy(csv_src, csv_dst)
        created.append("data/traceability_matrix.csv")

    # === Tool-owned templates (always update) ===
    for template_name, dest_path in TOOL_OWNED_TEMPLATES:
        src = templates_dir / template_name
        dst = target / dest_path
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.exists():
            was_modified = dest_path in modified_files
            user_action = user_decisions.get(dest_path, "overwrite")
            action, content_hash = _install_file_with_hash(
                src, dst, is_dev_mode, was_modified, user_action
            )
            if content_hash:
                new_hashes[dest_path] = content_hash
            if "symlink" in action:
                symlinked.append(dest_path)
            elif action == "skipped":
                skipped.append(dest_path)
            elif action == "backed_up_and_updated":
                backed_up.append(dest_path)
            elif action == "updated":
                updated.append(dest_path)
            else:
                created.append(dest_path)

    # === Create .claude/settings.json with permissions (USER-OWNED) ===
    settings_path = target / ".claude" / "settings.json"

    if settings_path.exists() and not args.force:
        skipped.append(".claude/settings.json")
    else:
        permissions: list[str] = []

        # Add permissions for bundled docs (used by specialist agents)
        docs_permission_path = _to_claude_permission_path(str(docs_path))
        permissions.extend(
            [
                f"Read({docs_permission_path}/**)",
                f"Grep({docs_permission_path}/**)",
                f"Glob({docs_permission_path}/**)",
            ]
        )

        # Add permissions for editable dependencies from pyproject.toml
        editable_paths = _detect_editable_deps(target)
        for p in editable_paths:
            permissions.append(f"Read({_to_claude_permission_path(p)}/**)")

        settings = {"permissions": {"allow": permissions}}
        settings_path.write_text(json.dumps(settings, indent=2) + "\n")
        created.append(f".claude/settings.json ({len(permissions)} permissions)")

    # === Update .gitignore for dev mode ===
    if is_dev_mode:
        if _update_gitignore_for_dev_mode(target):
            updated.append(".gitignore (added dev mode paths)")

    # === Save tool hashes (normal mode only) ===
    if not is_dev_mode and new_hashes:
        _save_tool_hashes(
            target, {"version": "1.0.0", "commit": _get_git_commit(), "files": new_hashes}
        )

    # === Print summary ===
    if is_dev_mode:
        print(f"\nInitialized MBSE project in {target} (dev mode)")
    else:
        print(f"\nInitialized MBSE project in {target}")
    print("")

    if symlinked:
        print(f"Symlinked ({len(symlinked)}) - dev mode, points to source:")
        for item in symlinked:
            print(f"  @ {item}")

    if created:
        print(f"\nCreated ({len(created)}):")
        for item in created:
            print(f"  + {item}")

    if updated:
        print(f"\nUpdated ({len(updated)}) - tool-managed files refreshed:")
        for item in updated:
            print(f"  ~ {item}")

    if backed_up:
        print(f"\nBacked up ({len(backed_up)}) - originals saved to .backup:")
        for item in backed_up:
            print(f"  B {item}")

    if skipped:
        print(f"\nSkipped ({len(skipped)}) - user files preserved:")
        for item in skipped:
            print(f"  . {item}")

    if not created and not updated and not symlinked and not backed_up:
        print("Everything up to date.")
    elif created or updated or symlinked or backed_up:
        print("")
        print("Next steps:")
        print("  1. Run /onboard to configure your project and learn the workflow")
        print("  2. Or manually edit knowledge/SOURCE_INDEX.md and start with /design-model")

    return EXIT_SUCCESS


def cmd_install_commands(args: argparse.Namespace) -> int:
    """Install MBSE commands to a project.

    Copies MBSE command files to .claude/commands/ in target directory.
    """
    if args.list:
        print("Available MBSE commands:")
        for cmd in MBSE_COMMANDS:
            print(f"  - {cmd}")
        print("")
        print(f"Total: {len(MBSE_COMMANDS)} commands")
        return EXIT_SUCCESS

    target_dir = Path(args.directory).resolve()
    if not target_dir.exists():
        print(f"Error: Directory does not exist: {args.directory}", file=sys.stderr)
        return EXIT_FAILURE

    commands_target = target_dir / ".claude" / "commands"
    commands_target.mkdir(parents=True, exist_ok=True)

    source_commands = get_commands_dir()
    installed = 0
    skipped = 0

    for cmd in MBSE_COMMANDS:
        src = source_commands / cmd
        dst = commands_target / cmd

        if not src.exists():
            print(f"Warning: Source not found: {cmd}", file=sys.stderr)
            continue

        if dst.exists() and not args.force:
            print(f"Skipping (exists): {cmd} (use --force to overwrite)")
            skipped += 1
            continue

        shutil.copy(src, dst)
        print(f"Installed: {cmd}")
        installed += 1

    print("")
    print(f"Installed: {installed}, Skipped: {skipped}")
    return EXIT_SUCCESS


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        prog="agentic-mbse",
        description="Domain-agnostic MBSE toolkit for AI-assisted systems engineering",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # validate command
    validate_parser = subparsers.add_parser(
        "validate",
        help="Run quality validation on SysML models",
    )
    validate_parser.add_argument(
        "path",
        nargs="?",
        default="models",
        help="Path to models directory (default: models)",
    )
    validate_parser.add_argument(
        "--complete",
        action="store_true",
        help="Run all levels regardless of failures",
    )
    validate_parser.add_argument(
        "--level",
        type=int,
        choices=range(1, 7),
        metavar="N",
        help="Run only level N (1-6)",
    )
    validate_parser.add_argument(
        "--verbose",
        action="store_true",
        help="Verbose output",
    )
    validate_parser.set_defaults(func=cmd_validate)

    # init command
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize project with SOURCE_INDEX.md and .claude/commands/",
    )
    init_parser.add_argument(
        "path",
        nargs="?",
        help="Target directory (default: current directory)",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite ALL files including user-owned ones (SOURCE_INDEX.md, OVERVIEW.md, settings.json, etc.)",
    )
    init_parser.add_argument(
        "--dev",
        action="store_true",
        help="Development mode: symlink tool-owned files instead of copying (requires source checkout)",
    )
    init_parser.set_defaults(func=cmd_init)

    # install-commands command
    install_parser = subparsers.add_parser(
        "install-commands",
        help="Install MBSE commands to a project",
    )
    install_parser.add_argument(
        "directory",
        nargs="?",
        default=".",
        help="Target directory (default: current directory)",
    )
    install_parser.add_argument(
        "--list",
        action="store_true",
        help="List available commands without installing",
    )
    install_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing command files",
    )
    install_parser.set_defaults(func=cmd_install_commands)

    # status command
    status_parser = subparsers.add_parser(
        "status",
        help="Show project status dashboard",
    )
    status_parser.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output as JSON instead of markdown",
    )
    status_parser.set_defaults(func=cmd_status)

    # pm command group (delegated to pm_cli module)
    from agentic_mbse.cli.pm_cli import register_pm_subcommands

    register_pm_subcommands(subparsers)

    # extract command (delegated to extract_cli module)
    from agentic_mbse.cli.extract_cli import register_extract_subcommand

    register_extract_subcommand(subparsers)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return EXIT_SUCCESS

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
