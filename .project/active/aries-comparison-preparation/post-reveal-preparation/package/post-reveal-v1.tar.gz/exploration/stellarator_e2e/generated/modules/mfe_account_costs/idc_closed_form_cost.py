"""IDC_Closed_Form_CostModule Module Wrapper

TEAx module for IDC_Closed_Form_Cost calculation.

CAS60 interest-during-construction line (closed form, uniform spend):

  f_idc = ((1 + interest_rate) ** construction_years - 1)
          / (interest_rate * construction_years) - 1
  cost  = f_idc * overnight_cost

Real construction_years retains its existing analytic extension. WI-028
Option C (owner-ruled): this line is A-2-checked and reported but
EXCLUDED from total_capital; the DCF idc_factor is untouched.

*Source**: /home/reid/1cfe/1costingfe/src/costingfe/layers/costs.py (pin 0254385)
*Ref**: costs.py:286-297 (cas60_idc)
*Basis**: Uniform-spend closed-form interest during construction
Native manual completion evaluates the retained equation above for Real T.
The zero-interest factor is exactly zero. Near zero, a generalized-binomial
series avoids cancellation; outside its documented switch, factoring T-1
retains the one-year zero. Reported IDC remains excluded from headline
total capital and is distinct from the headline midpoint multiplier.

*Source**: models/library/analyses/mfe_account_costs.sysml
*Ref**: IDC Closed-Form Cost, uniform-spend f_idc and cost equations; work/active/WI-052_mfe-financial-rate-limits/design.md, Numerical method and justification
Preceding external citations are inherited and not reverified in WI-052.
*Basis**: equivalent rate-limit arithmetic; independent 100-digit factor and public-wrapper tests passed 2026-09-12
*Last Updated**: 2026-09-12 (native equation and numerical method verification)

Inputs:
    - overnight_cost: overnight_cost parameter
    - interest_rate: interest_rate parameter
    - construction_years_in: construction_years_in parameter

Outputs:
    - cost: cost result

SysML Source: root-0/analyses/mfe_account_costs.sysml:712

SysML Source: root-0/analyses/mfe_account_costs.sysml:712

GAP: Code generator does NOT implement calc logic - only wrapper structure.
Handwritten implementation required in handwritten/mfe_account_costs/idc_closed_form_cost_impl.py
"""

from pydantic import BaseModel, Field, RootModel
from simkit.core.base import ModuleBase, ModuleResult

from stellarator_tea.primitives import Float


class IDC_Closed_Form_CostInput(BaseModel):
    """Input model for IDC_Closed_Form_CostModule.

    Attributes:
        overnight_cost: overnight_cost input
        interest_rate: interest_rate input
        construction_years_in: construction_years_in input
    """
    overnight_cost: float = Field(..., description="overnight_cost input")
    interest_rate: float = Field(..., description="interest_rate input")
    construction_years_in: float = Field(..., description="construction_years_in input")


class IDC_Closed_Form_CostModule(ModuleBase[IDC_Closed_Form_CostInput, Float]):
    """TEAx module for IDC_Closed_Form_Cost calculation.

CAS60 interest-during-construction line (closed form, uniform spend):

  f_idc = ((1 + interest_rate) ** construction_years - 1)
          / (interest_rate * construction_years) - 1
  cost  = f_idc * overnight_cost

Real construction_years retains its existing analytic extension. WI-028
Option C (owner-ruled): this line is A-2-checked and reported but
EXCLUDED from total_capital; the DCF idc_factor is untouched.

*Source**: /home/reid/1cfe/1costingfe/src/costingfe/layers/costs.py (pin 0254385)
*Ref**: costs.py:286-297 (cas60_idc)
*Basis**: Uniform-spend closed-form interest during construction
Native manual completion evaluates the retained equation above for Real T.
The zero-interest factor is exactly zero. Near zero, a generalized-binomial
series avoids cancellation; outside its documented switch, factoring T-1
retains the one-year zero. Reported IDC remains excluded from headline
total capital and is distinct from the headline midpoint multiplier.

*Source**: models/library/analyses/mfe_account_costs.sysml
*Ref**: IDC Closed-Form Cost, uniform-spend f_idc and cost equations; work/active/WI-052_mfe-financial-rate-limits/design.md, Numerical method and justification
Preceding external citations are inherited and not reverified in WI-052.
*Basis**: equivalent rate-limit arithmetic; independent 100-digit factor and public-wrapper tests passed 2026-09-12
*Last Updated**: 2026-09-12 (native equation and numerical method verification)

Inputs:
    - overnight_cost: overnight_cost parameter
    - interest_rate: interest_rate parameter
    - construction_years_in: construction_years_in parameter

Outputs:
    - cost: cost result

SysML Source: root-0/analyses/mfe_account_costs.sysml:712

    SysML Source: root-0/analyses/mfe_account_costs.sysml:712

    Calculation Specification:
        See documentation:
CAS60 interest-during-construction line (closed form, uniform spend):

  f_idc = ((1 + interest_rate) ** construction_years - 1)
          / (interest_rate * construction_years) - 1
  cost  = f_idc * overnight_cost

Real construction_years retains its existing analytic extension. WI-028
Option C (owner-ruled): this line is A-2-checked and reported but
EXCLUDED from total_capital; the DCF idc_factor is untouched.

*Source**: /home/reid/1cfe/1costingfe/src/costingfe/layers/costs.py (pin 0254385)
*Ref**: costs.py:286-297 (cas60_idc)
*Basis**: Uniform-spend closed-form interest during construction
Native manual completion evaluates the retained equation above for Real T.
The zero-interest factor is exactly zero. Near zero, a generalized-binomial
series avoids cancellation; outside its documented switch, factoring T-1
retains the one-year zero. Reported IDC remains excluded from headline
total capital and is distinct from the headline midpoint multiplier.

*Source**: models/library/analyses/mfe_account_costs.sysml
*Ref**: IDC Closed-Form Cost, uniform-spend f_idc and cost equations; work/active/WI-052_mfe-financial-rate-limits/design.md, Numerical method and justification
Preceding external citations are inherited and not reverified in WI-052.
*Basis**: equivalent rate-limit arithmetic; independent 100-digit factor and public-wrapper tests passed 2026-09-12
*Last Updated**: 2026-09-12 (native equation and numerical method verification)

    IMPLEMENTATION: See stellarator_tea.handwritten.mfe_account_costs.idc_closed_form_cost_impl
    for manual implementation.

    NOTE: Single-output module - returns Float directly (no MultiOutput needed).
    """

    name: str = "IDC_Closed_Form_CostModule"
    version: str = "v0.1"

    def validate_and_fill_default(
        self, overnight_cost: float, interest_rate: float, construction_years_in: float    ) -> IDC_Closed_Form_CostInput:
        """Validate inputs and fill defaults.

        Args:
            overnight_cost: overnight_cost input
            interest_rate: interest_rate input
            construction_years_in: construction_years_in input

        Returns:
            Validated input model
        """
        return IDC_Closed_Form_CostInput(overnight_cost=overnight_cost, interest_rate=interest_rate, construction_years_in=construction_years_in)

    def run(
        self, overnight_cost: float, interest_rate: float, construction_years_in: float    ) -> ModuleResult[Float]:
        """Execute calculation.

        Args:
            overnight_cost: overnight_cost input
            interest_rate: interest_rate input
            construction_years_in: construction_years_in input

        Returns:
            Module result with Float (single-output mode)
        """
        # Validate inputs
        validated_inputs = self.validate_and_fill_default(overnight_cost, interest_rate, construction_years_in)

        # Import handwritten implementation
        from stellarator_tea.handwritten.mfe_account_costs.idc_closed_form_cost_impl import (
            run_idc_closed_form_cost,
        )

        # Execute implementation - returns single value
        cost = run_idc_closed_form_cost(validated_inputs)

        # Single output - return Float directly (RootModel[float])
        # TEAx assigns entire return value to the one channel declared in YAML
        return ModuleResult(data=Float(cost))
