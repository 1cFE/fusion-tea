"""Constraint module for stellarator_09__stellaris__represented_coolant_fill_ok__e6341404f9f2ddda (Item 7 / D2/D3/D9).

Effective predicate: stellarator_09::stellaris::represented_coolant_fill_ok in owner instance stellarator_09__stellaris.
Three-valued (Kleene) semantics. A verdict against the assertion does not itself raise (INV-3).
"""

from pydantic import BaseModel
from simkit.config.schema import MultiOutput
from simkit.core.base import ModuleBase, ModuleResult

from stellarator_tea.schemas.constraint_types import ConstraintEvaluation
from stellarator_tea.modules.constraints.predicates import _finalize_assertion, constraint_pred_definition_mfe_viability__represented_coolant_fill


class StellarisRepresentedCoolantFillOkConstraintInput(BaseModel):
    """Exact input schema: one field per resolved formal."""
    defined_in: float
    helium_margin_in: float
    salt_margin_in: float


class StellarisRepresentedCoolantFillOkConstraintOutput(MultiOutput):
    evaluation: ConstraintEvaluation


class StellarisRepresentedCoolantFillOkConstraintModule(ModuleBase[StellarisRepresentedCoolantFillOkConstraintInput, StellarisRepresentedCoolantFillOkConstraintOutput]):
    name: str = "stellarator_09__stellaris__represented_coolant_fill_ok__e6341404f9f2ddda"
    version: str = "v0.1"

    CONSTRAINT_ID = "stellarator_09__stellaris__represented_coolant_fill_ok__e6341404f9f2ddda"

    def run(self, defined_in: float, helium_margin_in: float, salt_margin_in: float) -> ModuleResult[StellarisRepresentedCoolantFillOkConstraintOutput]:
        StellarisRepresentedCoolantFillOkConstraintInput(defined_in=defined_in, helium_margin_in=helium_margin_in, salt_margin_in=salt_margin_in)  # validate every resolved formal
        body = constraint_pred_definition_mfe_viability__represented_coolant_fill(defined_in=defined_in, helium_margin_in=helium_margin_in, salt_margin_in=salt_margin_in)
        verdict = _finalize_assertion(
            body,
            is_negated=False,
            expected_value=True,
        )
        return ModuleResult(
            data=StellarisRepresentedCoolantFillOkConstraintOutput(
                evaluation=ConstraintEvaluation(
                    constraint_id=self.CONSTRAINT_ID,
                    actual_value=verdict.actual_value,
                    status=verdict.status,
                    margin=verdict.margin,
                    observed={"defined_in": float(defined_in), "helium_margin_in": float(helium_margin_in), "salt_margin_in": float(salt_margin_in)},
                )
            )
        )
