"""Auto-generated implementation for Magnet_Capital.

AUTO_IMPLEMENTED = True

SysML Source: root-0/analyses/mfe_magnet_cost.sysml:181

SysML Expressions:
    insulation_stock_cost = 0.0
    capital_cost = winding_cost + structure_cost_in + insulation_stock_cost
    
Documentation:
CAS22.1.3 magnet account rollup (WI-035 D6): the decomposed magnet
capital is the sum of the separately sized sub-accounts. Kept as a
calc def so the plant's magnet.capital_cost redefinition stays a
reference binding (the codegen-proven WI-021 pattern), not an
arithmetic redefinition expression (dropped by the pinned codegen,
WI-030).

*Source**: work/completed/20260901_WI-035_magnet-closure/design.md
*Ref**: design D6 (rollup + comparison channel); design Risk 1
(redefinition envelope)
*Basis**: sum of winding-pack, all-in magnet structure and conditional additional sheet-stock sub-accounts; sheet inclusion in winding remains uncertain (WI-063 design).
"""

AUTO_IMPLEMENTED = True

from stellarator_tea.modules.mfe_magnet_cost.magnet_capital import Magnet_CapitalInput


def run_magnet_capital(inputs: Magnet_CapitalInput) -> float:
    """Execute Magnet_Capital calculation.

CAS22.1.3 magnet account rollup (WI-035 D6): the decomposed magnet
capital is the sum of the separately sized sub-accounts. Kept as a
calc def so the plant's magnet.capital_cost redefinition stays a
reference binding (the codegen-proven WI-021 pattern), not an
arithmetic redefinition expression (dropped by the pinned codegen,
WI-030).

*Source**: work/completed/20260901_WI-035_magnet-closure/design.md
*Ref**: design D6 (rollup + comparison channel); design Risk 1
(redefinition envelope)
*Basis**: sum of winding-pack, all-in magnet structure and conditional additional sheet-stock sub-accounts; sheet inclusion in winding remains uncertain (WI-063 design).

SysML Source: root-0/analyses/mfe_magnet_cost.sysml:181

SysML Expressions:
    insulation_stock_cost = 0.0
    capital_cost = winding_cost + structure_cost_in + insulation_stock_cost
    
Documentation:
CAS22.1.3 magnet account rollup (WI-035 D6): the decomposed magnet
capital is the sum of the separately sized sub-accounts. Kept as a
calc def so the plant's magnet.capital_cost redefinition stays a
reference binding (the codegen-proven WI-021 pattern), not an
arithmetic redefinition expression (dropped by the pinned codegen,
WI-030).

*Source**: work/completed/20260901_WI-035_magnet-closure/design.md
*Ref**: design D6 (rollup + comparison channel); design Risk 1
(redefinition envelope)
*Basis**: sum of winding-pack, all-in magnet structure and conditional additional sheet-stock sub-accounts; sheet inclusion in winding remains uncertain (WI-063 design).

Args:
    inputs: Input parameters validated against Magnet_CapitalInput schema

Returns:
    float: capital_cost

Example:
    >>> inputs = Magnet_CapitalInput(...)
    >>> result = run_magnet_capital(inputs)
    """
    return ((inputs.winding_cost + inputs.structure_cost_in) + inputs.insulation_stock_cost)
